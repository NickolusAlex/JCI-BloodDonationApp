<?php 

    $rand  = rand(1000, 9999);
    $d = new DateTime();
    $micro_time = $d->format("Hisv");
    $random_sc = $rand . $micro_time;
    
    
    $user_id = $_POST['LOGIN_USER'];
   
    $user_details_sql = "SELECT * FROM user_creation U where user_id = '$user_id' AND active_status = 1";
    $prepare = $DB_conn->prepare($user_details_sql);
    $exc = $prepare->execute();
   
    $user_details = $prepare -> fetchAll();
    
    $name = $dob = $last_donated = $phone_number = $email = $password = $blood_type = $district = $state = $pincode = $area = $address = $offten_time = "";
    if(!empty($user_details)){
        $name = $user_details[0]['name'];
        $phone_number = $user_details[0]['phone_number'];
        $user_email = $user_details[0]['user_email'];
        $dob = $user_details[0]['date'];
        $password = $user_details[0]['password'];
        $district = $user_details[0]['district'];
        $state = $user_details[0]['state'];
        $area = $user_details[0]['area'];
        $pincode = $user_details[0]['pincode'];
        $address = $user_details[0]['address'];
        $blood_type = $user_details[0]['blood_type'];
        $offten_time = $user_details[0]['offten_time'];
        $last_donated = $user_details[0]['last_donated'];
    }
?>
<link rel="stylesheet" type="text/css" href="css/util.css">
<link rel="stylesheet" type="text/css" href="css/main.css">
<link rel="stylesheet" href="css/signup_donor.css">
<style>
  /*.container-fluid *{*/
  /*     text-transform:capitalize; */
  /*  }*/
    .bg-danger {
        background-color: #C20101 !important;
    }

    body {
        background-color: white !important;
    }

    .wrap-input1000 {
        position: relative;
        width: 100%;
        z-index: 1;
    }

    .input1000 {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        font-size: 12px;
        line-height: 1.2;
        color: #333333;
        display: block;
        width: 100%;
        background: #fff;
        height: 46px;
        /* border-radius: 25px; */
        padding: 3px 30px 3px 66px;
        box-shadow: -3px 6px 7px -2px rgba(118, 112, 112, 0.75);
        -webkit-box-shadow: -3px 6px 7px -2px rgba(118, 112, 112, 0.75);
        -moz-box-shadow: -3px 6px 7px -2px rgba(118, 112, 112, 0.75);
    }


    .focus-input1000 {
        display: block;
        position: absolute;
        border-radius: 25px;
        bottom: 0;
        left: 0;
        z-index: -1;
        width: 100%;
        height: 100%;
        box-shadow: 0px 0px 0px 0px;
        color: rgba(234, 125, 0, 0.945);
    }

    .input1000:focus+.focus-input1000 {
        -webkit-animation: anim-shadow 0.5s ease-in-out forwards;
        animation: anim-shadow 0.5s ease-in-out forwards;
    }

    .symbol-input1000 {
        font-size: 15px;
        color: #f80000;

        display: -webkit-box;
        display: -webkit-flex;
        display: -moz-box;
        display: -ms-flexbox;
        display: flex;
        align-items: center;
        position: absolute;
        border-radius: 25px;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 100%;
        padding-left: 30px;
        pointer-events: none;

        -webkit-transition: all 0.4s;
        -o-transition: all 0.4s;
        -moz-transition: all 0.4s;
        transition: all 0.4s;
    }

    .input1000:focus+.focus-input1000+.symbol-input1000 {
        color: #fb7100;
        padding-left: 23px;
    }

    .login100-form-title {
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
        font-size: 15px;
        color: #666666;
        line-height: 1.2;
        text-align: center;
        margin-bottom: 1vh;
        width: 100%;
        display: block;
    }

    .image-logo {
        top: 0;
        margin-top: -13.4414vh;
        /* font-size: 7vw; */
        margin-left: 37.5vw;
        /* padding: 10px 15px; */
        /* border-radius: 50%; */
        /* background-color: #666666; */
        color: white;
        width: 50vw;
        height: 20vh;
    }

    /* Centered text */
    .centered {
        position: absolute;
        top: 1vh;
        left: 15%;
        transform: translate(-6vw, 4vh);
        font-weight: 500;
        font-size: 5vw;
    }

    .left-top {
        position: absolute;
        color: rgb(255, 255, 255);
        top: 1vh;
        left: 15vw;
        transform: translate(-10vw, 0vh);
        font-weight: 500;
        font-size: 4vw;
    }

    .p-t-10 {
        padding-top: 10vh
    }

    .f-v6 {
        font-size: 7vw;
    }

    .fw-600 {
        font-weight: 600;
    }
    .h-50v{
        height: 65vh;
    }
</style>
<div style="padding-left: 0px; width: 100vw !important;" class="sticky-top container-fluid h20 bg-white ">
    <div style="width: 100vw !important;" class="h-100 d-flex align-items-center sticky-top">
        <img src="images/layout-red.png" style="width: 101vw; height: 25vh;" alt="">
        
        <input type="hidden" value="<?php echo $random_sc; ?>" name="random_sc" id="random_sc">
        
        <div class="centered text-white" style="text-transform:capitalize; ">
            Edit Donor Profile
        </div>
        <div onclick="fetch_page('home')" class="left-top">
            <i class="fas fa-chevron-left fa-1x"></i>
        </div>
    </div>
    <div class="h-100 d-flex align-items-center sticky-top">
        <div class="image-logo">
            <img  src="icons/p1.png" id="profile_img" style="width: 25vw; padding-top: 2vh;" alt="">
            <input id="profile_input" accept="image/*" name="profile_input" type="file" style="display:none;" />
        </div>
    </div>


</div>

<div class="container-fluid p-bt-5 text-center bg-white ">
    <span class="f-v7 fw-600" style="text-transform:capitalize; ">Fill the details</span>
</div>

<div style="width: 100%; padding-bottom: 30vh;"
    class="bg-white container-fluid overflow-auto h-50v p-b-v20 bg-white d-flex justify-content-center">

    <div style="width: 90%;">


        <div style="padding-top: 6vh;" class="login100-form validate-form bg-white ">

            <div class="wrap-input1000 m-b-30" data-validate="Name is required">
                <input class="input1000" type="text" value="<?php echo $name; ?>" name="user_name" id="user_name" placeholder="Name">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fa fa-user"></i>
                </span>
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Date of Birth is required">
                <input class="input1000 " type="text" value="<?php echo $dob; ?>"
                    onfocus="(this.type='date')" onfocusout="if(this.value==''){(this.type='text')}" name="date" id="date" placeholder="Date Of Birth">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fa fa-calendar-alt"></i>
                </span>
            </div>
            
            
            <div class="wrap-input1000 m-b-30" data-validate="Phone is required">
                <input class="input1000" pattern="[1-9]{1}[0-9]{9}" value="<?php echo $phone_number; ?>" maxlength="10" type="text" name="phone_number" id="phone_number" placeholder="Phone Number">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fa fa-phone"></i>
                </span>
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Email is required">
                <input class="input1000" type="email" value="<?php echo $user_email; ?>" name="user_email" id="user_email" placeholder="Email">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fa fa-envelope"></i>
                </span>
            </div>
            
            
            <div class="wrap-input1000 m-b-30" data-validate="Password is required">
                <input class="input1000" type="password" name="password" value="<?php echo $password; ?>" id="password" placeholder="Password">
                <span class="focus-input1000"></span> 
                <span class="symbol-input1000">
                    <i class="fa fa-key"></i>
                </span>
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Blood Group is required">
                <select style="border:none" class="input1000" name="blood_group" id="blood_group" placeholder="blood_group">
                    <option value="">Select Blood Group</option>
                            <?php 
                            $SQL = "SELECT * FROM blood_type";
                            $prepare = $DB_conn -> prepare($SQL);
                            $exc = $prepare->execute();
                            $blood_details = $prepare->fetchAll();
                            foreach($blood_details as $detail){
                                ?>
                                <option <?php echo ($blood_type == $detail['blood_id']) ? ("selected") : (""); ?> value='<?php echo $detail['blood_id']; ?>'><?php echo $detail['blood_name']; ?></option>
                                <?php
                            }
                            ?>
                </select>
                <span class="focus-input1000"></span> 
                <span class="symbol-input1000">
                    <i class="fa fa-tint"></i>
                </span>
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Offten is required">
                <select name="offten_time" id="offten_time" style="border:none" class="input1000" >
                  <option >How Often You Donate Blood</option>
                  <option <?php echo ($offten_time == '3') ? ("selected") : (""); ?> value='3'>3 Months</option>
                  <option <?php echo ($offten_time == '4') ? ("selected") : (""); ?> value='4'>4 Months</option>
                  <option <?php echo ($offten_time == '5') ? ("selected") : (""); ?> value='5'>5 Months</option>
                  <option <?php echo ($offten_time == '6') ? ("selected") : (""); ?> value='6'>6 Months</option>
                </select>
                <span class="focus-input1000"></span> 
                <span class="symbol-input1000">
                    <i class="fas fa-history"></i>
                </span>
            </div>
            
            
            <div>
                Last Donate Blood
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Last Blood Donated is required">
                <input class="input1000 " type="text" value="<?php echo $last_donated; ?>"
                    onfocus="(this.type='date')" onfocusout="if(this.value==''){(this.type='text')}" name="last_donated" id="last_donated" placeholder="Last Blood Donated">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <!--<i class="fa fa-calendar-alt"></i>-->
                    <i class="fas fa-hourglass-start"></i>
                </span>
            </div>
            
            
            <div class="wrap-input1000 m-b-30" data-validate="District is required">
                <select name="district" id="district" style="border:none" class="input1000" >
                        <?php      
                        $district_details_sql = "SELECT * FROM districts";
                        $prepare = $DB_conn->prepare($district_details_sql);
                        $exc = $prepare->execute();
                       
                       $district_details = $prepare -> fetchAll(); 
                       foreach($district_details as $val){?>
                       <option <?php echo ($district == $val['district_name']) ? ("selected") : (""); ?> value='<?php echo $val['district_name']; ?>'><?php echo $val['district_name']; ?></option>
                       <?php } ?>
                </select>
                <span class="focus-input1000"></span> 
                <span class="symbol-input1000">
                    <i class="fa fa-location-arrow"></i>
                </span>
            </div>
            
            <div class="wrap-input1000 m-b-30" data-validate="Address is required">
                <input class="input1000" type="text" value="<?php echo $address; ?>" name="address" id="address" placeholder="Address">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <!--<i class="fa fa-telegram"></i>-->
                    <!--<i class="fa fa-bell"></i>-->
                    <i class="fas fa-address-card"></i>
                </span>
            </div>
            <div class="wrap-input1000 m-b-30" data-validate="Pincode is required">
                <input class="input1000" type="text" value="<?php echo $pincode; ?>" name="pincode" id="pincode" placeholder="Pincode">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fas fa-map-pin"></i>
                </span>
            </div>
            <div class="wrap-input1000 m-b-30" data-validate="Area is required">
                <input class="input1000" type="text" value="<?php echo $area; ?>" name="area" id="area" placeholder="Area">
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fa fa-plus"></i>
                </span>
            </div>
            
             <div class="wrap-input1000 m-b-30" data-validate="State is required">
                <!--<input class="input1000" type="state" value="" name="state" id="state" placeholder="State">-->
                <select name="state" id="state" style="border:none" class="input1000" >
                    <option>Select State</option>
                    <?php      
                    $user_details_sql1 = "SELECT * FROM state_list";
                    $prepare = $DB_conn->prepare($user_details_sql1);
                    $exc = $prepare->execute();
                    
                    $user_details = $prepare -> fetchAll(); 
                    foreach($user_details as $val){?>
                    
                    <option <?php echo ($state == $val['state']) ? ("selected"): (""); ?> value='<?php echo $val['state']; ?>'><?php echo $val['state']; ?></option>
                    
                    <?php } ?>
                </select>
                
                <span class="focus-input1000"></span>
                <span class="symbol-input1000">
                    <i class="fas fa-map-marker-alt"></i>
                </span>
            </div>
            
            <div class="container-login100-form-btn p-t3 p-b-25">
                <button onclick="user_edit()" class="login100-form-btn">
                    Update
                </button>
            </div>

        </div>
    </div>

</div>
<script>


 function user_edit(){
        
        var CONNECTION_DETAIL = checkConnection();

        var ONLINE_STATUS = window.localStorage.getItem("online_status");

        var LOGIN_USER = window.localStorage.getItem("user_id");

        if (ONLINE_STATUS != "online") {
            $("#app").load('pages/error_offline.html');
            return false;
        }
        if (CONNECTION_DETAIL == "No network connection") {
            $("#app").load("pages/error_interrupted_connection.html");
            return false;
        }
        
        
        var random_sc     = $("#random_sc").val();
        
        var user_name     = $("#user_name").val();
        var date          = $("#date").val();
        var phone_number  = $("#phone_number").val();
        var user_email    = $("#user_email").val();
        var password      = $("#password").val();
        var blood_group   = $("#blood_group").val();
        var offten_time   = $("#offten_time").val();
        var district      = $("#district").val();
        var address       = $("#address").val();
        var pincode       = $("#pincode").val();
        var area          = $("#area").val();
        var state         = $("#state").val();
        var last_donated  = $("#last_donated").val();
        
        
        var signup_form = new FormData();
        
        
        signup_form.append("REQUEST_KIND", "ACCESS_VERIFICAION");
        signup_form.append("VALIDATION_ACTION", "EDIT_PROFILE");
        
        signup_form.append("random_no", random_sc);
        
        signup_form.append("user_name", user_name);
        signup_form.append("date", date);
        signup_form.append("phone_number", phone_number);
        signup_form.append("user_email", user_email);
        signup_form.append("password", password);
        signup_form.append("blood_group", blood_group);
        signup_form.append("offten_time", offten_time);
        signup_form.append("district", district);
        signup_form.append("address", address);
        signup_form.append("pincode", pincode);
        signup_form.append("area", area);
        signup_form.append("state", state);
        
        signup_form.append("last_donated", last_donated);

        var cordova = device.cordova;
        var model = device.model;
        var version = device.version;
        var uuid = device.uuid;
        var platform = device.platform;
        
        signup_form.append('cordova', cordova);
        signup_form.append('model', model);
        signup_form.append('platform', platform);
        signup_form.append('uuid', uuid);
        signup_form.append('version', version);
        
        signup_form.append('LOGIN_USER', LOGIN_USER);
        


        if (user_name != "" && phone_number != "" && password!="" && user_email!="" && district != "" && blood_group != "") {

            $.ajax({
                url: URL_SITE,
                type: "POST",
                crossOrigin: true,
                contentType: false,
                cache: false,
                processData: false,
                data: signup_form,
                dataType: "JSON",
                success: function(msg) {
                    
                        if (msg.status_code == "REPEATED CONTACT") {
                                alert("You are already registered with this mobile number please login");
                        }
                        else if (msg.status_code == "SUCCESS") {
                            window.localStorage.setItem("random_no", random_sc);
                            fetch_page('home');
                        }  else {
                            alert(msg.status_code);
                        }
                    
                },
            });

        } else {
            alert("Fill Name/Phone Number/Password/Email/Blood Group/District");
        }
 
 }
</script>