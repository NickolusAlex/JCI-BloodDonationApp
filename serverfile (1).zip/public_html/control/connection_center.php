<?php

$servername = "localhost";
$username = "id17553295_ksn";
$password = "G0>MQBda_bgr%gtp";
$db_name = "id17553295_jci_app";

$DB_conn = new PDO("mysql:host=$servername;dbname=$db_name", $username, $password);
